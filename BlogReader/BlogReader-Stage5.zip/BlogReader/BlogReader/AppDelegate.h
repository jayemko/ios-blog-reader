//
//  AppDelegate.h
//  BlogReader
//
//  Created by Amit Bijlani on 12/6/12.
//  Copyright (c) 2012 Amit Bijlani. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
